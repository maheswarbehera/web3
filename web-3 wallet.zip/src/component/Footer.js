import React from 'react';

const Footer = () => {
  return (
    <div>
      <div className="copyright py-4">
            <p className="copy m-0">@copyright-2023</p>
        </div>
    </div>
  );
}

export default Footer;
