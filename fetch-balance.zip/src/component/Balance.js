import React from 'react';
import Wallet from './Wallet/Wallet';
// const Web3 = require('web3');

const Balance =  () => {

    // const ethRpcUrl =`https://crimson-summer-vineyard.ethereum-sepolia.discover.quiknode.pro/66d631d201dc0dad35b353a24ff329c8ed8b874d/`
    // const web3 = new Web3(ethRpcUrl);
    // const balance = await web3.eth.getBalance(address);
    // const bal = await web3.utils.fromWei(balance, "ether");
    // console.log(`Balance: ${bal} ETH`);
  return (
    <div>
        <Wallet/>
    </div>
  );
}

export default Balance;
