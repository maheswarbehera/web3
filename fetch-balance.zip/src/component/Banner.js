import React from 'react';
import banner from '../component/boss blockchain 1.png'
function Banner() {
  return (
    <div>
      <img src={banner} alt="" className='w-100' />
    </div>
  );
}

export default Banner;
