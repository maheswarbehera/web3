import React from 'react';

function Header() {
  return (
    <>
      <div className="header" style={{padding:'20px'}}>
       <div className="container">
        <span className='logo text-sm-center'>Web3-Converter</span>
       </div>
      </div>
    </>
  );
}

export default Header;
